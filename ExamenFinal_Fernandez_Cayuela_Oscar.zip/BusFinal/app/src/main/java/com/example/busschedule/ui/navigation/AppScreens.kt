package com.example.busschedule.ui.navigation

sealed class AppScreens(val ruta: String){
    object menu: AppScreens("menu")
    object lista: AppScreens("lista")
    object frecuencia: AppScreens("freciencia")
    object noticias: AppScreens("noticias")
    object usuario: AppScreens("usuario")
}