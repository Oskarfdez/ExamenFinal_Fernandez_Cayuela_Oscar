package com.example.busschedule.ui.menu


import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.busschedule.ui.navigation.AppScreens


@Composable
fun InicioScreen(navController: NavController){
    Column {
        Spacer(modifier = Modifier.height(16.dp))
        Boton(onButtonClick = { navController.navigate(AppScreens.lista.ruta) }, text = "Lista")
        Spacer(modifier = Modifier.height(16.dp))
        Boton(onButtonClick = { navController.navigate(AppScreens.noticias.ruta) }, text = "Noticias")
        Spacer(modifier = Modifier.height(16.dp))
        Boton(onButtonClick = { navController.navigate(AppScreens.frecuencia.ruta) }, text = "Frecuencia")
        Spacer(modifier = Modifier.height(16.dp))
        Boton(onButtonClick = { navController.navigate(AppScreens.usuario.ruta) }, text = "Usuario")
        Spacer(modifier = Modifier.height(16.dp))
    }
}
@Composable
fun Boton(onButtonClick: () -> Unit, text: String){
    Button(onClick = { onButtonClick() }) {
        Text(text = text)
    }}