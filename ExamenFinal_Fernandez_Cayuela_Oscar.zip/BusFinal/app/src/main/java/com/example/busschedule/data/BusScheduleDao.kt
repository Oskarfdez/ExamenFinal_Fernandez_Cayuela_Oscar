package com.example.busschedule.data

import androidx.room.Dao
import androidx.room.Query
import kotlinx.coroutines.flow.Flow


@Dao
interface BusScheduleDao {
    @Query("""
        SELECT * FROM esquema 
        ORDER BY arrival_name ASC    
        """)
    fun getAll(): Flow<List<BusSchedule>>

    @Query("""
        SELECT * FROM esquema 
        WHERE stop_name = :stopName 
        ORDER BY arrival_name ASC 
        """)
    fun getByStopName(stopName: String): Flow<List<BusSchedule>>
}
